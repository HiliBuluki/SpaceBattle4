package com.example.myapplication_spacebattlenewhil4;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class BoardGame extends View {

    private Context context;
    Bitmap bitmapstarship;
    Player player;
    private Handler handler;

    private ThreadGame threadGame;

    ArrayList<Alien> arrayList;
    private boolean isRun = true;

    public BoardGame(Context context) {
        super(context);
        this.context = context;

        bitmapstarship = BitmapFactory.decodeResource(context.getResources(),R.drawable.spaceship);
        player = new Player(100,500,bitmapstarship);


        arrayList = new ArrayList<>();
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(),R.drawable.aliens);
        for (int i = 0; i < 2; i++) {
            Alien alien = new Alien(100 + i * 150,100,bitmap);
            arrayList.add(alien);
        }

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                for (int i = 0; i < 2; i++) {
                    arrayList.get(i).move();
                }

                invalidate();
                return false;
            }
        });

       threadGame = new ThreadGame();
       threadGame.start();
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        player.draw(canvas);

        for (int i = 0; i < 2; i++) {
            arrayList.get(i).draw(canvas);
        }
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_MOVE)
        {
            player.setNewLocation(event.getX());
        }

        invalidate();

        return true;
    }


    private class ThreadGame extends Thread{
        @Override
        public void run()
        {
            super.run();
            while (true)
            {
                try
                {
                    sleep(40);

                    if(isRun)
                        handler.sendEmptyMessage(0);
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace(); // אם האנדרואיד לא מצליח לקום(המשתמש פתח אפליקציה אחרת) אז זה שולח הודעת שגיאה במקום להתעופף
                }
            }
        }
    }


}
