package com.example.myapplication_spacebattlenewhil4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

public class GameActivity extends AppCompatActivity {

    BoardGame boardGame;
    TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {  //
        super.onCreate(savedInstanceState);  // קורא למתודה onCreate של מחלקת האב כדי לוודא שהאתחול הבסיסי מתבצע.
        setContentView(R.layout.activity_game);  // מגדיר את התצוגה של המסך לפי קובץ ה-.xml.

        boardGame = new BoardGame(this);  // יוצר מופע חדש של BoardGame שמייצג את לוח המשחק.
        setContentView(boardGame);  // משנה את התצוגה של ה-Activity כך שתציג את האובייקט boardGame במקום ה-XML.

        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {  // יוצר מופע של TextToSpeech להמרת טקסט לדיבור, ומוסיף מאזין שיבדוק מתי הרכיב מוכן.
            @Override
            public void onInit(int status) {  // מופעל כאשר מנוע ה-TextToSpeech מאותחל.
                if (status == TextToSpeech.SUCCESS) {  // בודק אם אתחול ה-TextToSpeech הצליח.
                    int lanS = textToSpeech.setLanguage(Locale.ENGLISH);  // מגדיר את שפת הדיבור לאנגלית.
                }
            }
        });
    }
}

