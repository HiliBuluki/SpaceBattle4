package com.example.myapplication_spacebattlenewhil4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.content.Intent;
import android.media.AudioManager;
import android.media.Image;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity implements
        View.OnClickListener {
    private Button btnInstruction, btnSetting, btnStartGame; // הפניות
    SoundPool soundPool;
    int clicksound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      //  soundPool = new SoundPool(3, AudioManager.STREAM_MUSIC, 0);
        // clicksound=soundPool.load(this,R.raw.clickbutton,1);
        btnInstruction = findViewById(R.id.btnInstruction);
        btnSetting = findViewById(R.id.btnSetting);
        btnStartGame = findViewById(R.id.btnStartGame);
        btnInstruction.setOnClickListener(this);
        btnSetting.setOnClickListener(this);
        btnStartGame.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == btnInstruction) {
            Intent i = new Intent(this, ActivityInstruction.class);
           // soundPool.play(clicksound, 1, 1, 0, 0, 1);
            startActivity(i);
        }

        if (v == btnSetting) {
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
        }
        if (v == btnStartGame) {
            Intent i = new Intent(this, GameActivity.class);
            startActivity(i);
          //  soundPool.play(clicksound, 1, 1, 0, 0, 1);

        }
    }
}